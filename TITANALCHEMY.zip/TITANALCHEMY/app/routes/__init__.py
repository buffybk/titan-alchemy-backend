# app/routes/__init__.py

from .auth import auth
from .product import product
from .cart import cart
from .order import order

# Now these blueprints can be easily registered in the app