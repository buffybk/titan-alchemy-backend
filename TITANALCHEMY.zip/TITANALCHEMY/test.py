from werkzeug.urls import url_decode

print("url_decode imported successfully")